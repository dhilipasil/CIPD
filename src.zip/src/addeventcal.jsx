// EventForm.js
import React, { useState } from 'react';
import './css/addeventcal.css'; // Include this CSS file for styling

const EventForm = ({ addEvent }) => {
  const [eventDetails, setEventDetails] = useState({
    eventName: '',
    eventTitle: '',
    eventDate: '',
    location: '',
    eventDescription: '',
  });

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEventDetails({ ...eventDetails, [name]: value });
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    addEvent(eventDetails); // Call the addEvent function from props
    setEventDetails({ eventName: '', eventTitle: '', eventDate: '', location: '', eventDescription: '' }); // Reset form fields
  };

  return (
    <div className="event-form-container">
      <form className="event-form" onSubmit={handleSubmit}>
        <h2 className="form-title">Create a New Event</h2>
        <div className="form-group">
          <label>Event Name</label>
          <input
            type="text"
            name="eventName"
            placeholder="Enter Event Name"
            value={eventDetails.eventName}
            onChange={handleChange}
            className="form-input"
          />
        </div>

        <div className="form-group">
          <label>Event Title</label>
          <input
            type="text"
            name="eventTitle"
            placeholder="Enter Event Title"
            value={eventDetails.eventTitle}
            onChange={handleChange}
            className="form-input"
          />
        </div>

        <div className="form-group">
          <label>Date</label>
          <input
            type="date"
            name="eventDate"
            value={eventDetails.eventDate}
            onChange={handleChange}
            className="form-input"
          />
        </div>

        <div className="form-group">
          <label>Location</label>
          <input
            type="text"
            name="location"
            placeholder="Enter Event Location"
            value={eventDetails.location}
            onChange={handleChange}
            className="form-input"
          />
        </div>

        <div className="form-group">
          <label>Event Details</label>
          <textarea
            name="eventDescription"
            placeholder="Enter Event Details"
            value={eventDetails.eventDescription}
            onChange={handleChange}
            className="form-textarea"
          ></textarea>
        </div>

        <div className="form-group">
          <label>Event Poster</label>
          <input type="file" className="form-file-input" />
        </div>

        <button type="submit" className="submit-button">
          Add Event
        </button>
      </form>
    </div>
  );
};

export default EventForm;
