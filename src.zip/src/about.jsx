import React from 'react';
import './css/about.css';

const AboutSection = () => {
  return (
  
    <section id="info-section-wrapper" className="info-section-wrapper">
      <h2 className="info-header">About CiPD</h2>
      <div className="info-text">
        <p className='parag'>
          CiPD was established at Nandha Engineering College in 2015 with the goal of sparking innovation in students and
          exposing them to real-world problems that need to be solved. The center encourages students to come up with ideas
          that demonstrate innovation, Intellectual Property Rights (IPR) potential, and commercial value.
        </p>
        <p className='parag'>
          CiPD connects students with mentors and experts to provide guidance in project-making, exhibitions, and hackathons. 
          Regular events such as Innovation Day, hackathons, and various competitions are part of CiPD's yearly schedule. 
          CiPD invites industry professionals, entrepreneurs, and successful startups to share their experiences with students 
          and faculty to foster a collaborative environment. The center also aims to build interdisciplinary networks and 
          provide students with a platform to better understand innovation, IPR, startups, and entrepreneurship.
        </p>
      </div>
    </section>
    
  );
};

const ContactSection = () => {
  return (
    <section id="connect-section-wrapper" className="connect-section-wrapper">
      <h2 className="connect-header">Contact Us</h2>
      <div className="connect-text">
        <p className='parag'>
          <strong>Nandha Engineering College (Autonomous)</strong><br />
          Approved by AICTE, New Delhi and Affiliated to Anna University, Chennai.<br />
          Perundurai, Erode - 638012, Tamil Nadu, India.<br />
          <strong>Email:</strong> <a href="mailto:principal@nandhaengg.org">principal@nandhaengg.org</a><br />
          <strong>Website:</strong> <a href="http://www.nandhaengg.org">www.nandhaengg.org</a><br />
          <strong>Phone:</strong> 04294-225595
        </p>
      </div>
    </section>
  );
};

const App = () => {
  return (
    <div className="app-content-wrapper">
      <AboutSection />
      <ContactSection />
    </div>
    
  );
};

export default App;
