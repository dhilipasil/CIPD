import React, { useState } from 'react';
import './css/Calendar.css'; // Make sure to update this CSS file for larger size and positioning
import { useNavigate } from 'react-router-dom';

const Calendar = () => {
  const navigate = useNavigate();
  const goToPage = (page) => {
    navigate(`/${page}`);
  };
  const [events, setEvents] = useState({});
  const [eventInput, setEventInput] = useState('');
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  const handleDateClick = (date) => {
    setSelectedDate(date);
    setEventInput(''); // Clear input when a new date is selected
  };

  const handleInputChange = (e) => {
    setEventInput(e.target.value);
  };

  const addEvent = () => {

  };

  const changeMonth = (increment) => {
    if (increment === 1) {
      if (currentMonth === 11) {
        setCurrentMonth(0);
        setCurrentYear(currentYear + 1);
      } else {
        setCurrentMonth(currentMonth + 1);
      }
    } else {
      if (currentMonth === 0) {
        setCurrentMonth(11);
        setCurrentYear(currentYear - 1);
      } else {
        setCurrentMonth(currentMonth - 1);
      }
    }
  };

  const renderCalendar = () => {
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate(); // Get number of days in the month
    const startDay = new Date(currentYear, currentMonth, 1).getDay(); // Get first day of the month
    const calendarDays = [];

    for (let i = 0; i < startDay; i++) {
      calendarDays.push(<td key={`empty-${i}`} className="empty-cell"></td>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const dateString = `${currentYear}-${(currentMonth + 1)
        .toString()
        .padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
      const isBooked = events[dateString] && events[dateString].length > 0;

      calendarDays.push(
        <td
          key={day}
          className={isBooked ? 'booked' : 'free'}
          onClick={() => handleDateClick(dateString)}
        >
          {day}
        </td>
      );
    }

    // Split into weeks (7 days)
    const weeks = [];
    for (let i = 0; i < calendarDays.length; i += 7) {
      weeks.push(
        <tr key={`week-${i}`}>
          {calendarDays.slice(i, i + 7)}
        </tr>
      );
    }

    return weeks;
  };

  return (
    <div className="calendar-container">
      <h2>Event Calendar</h2>
      <div className="month-navigation">
        <button onClick={() => changeMonth(-1)}>Prev</button>
        <span>{`${new Date(currentYear, currentMonth).toLocaleString('default', {
          month: 'long',
        })} ${currentYear}`}</span>
        <button onClick={() => changeMonth(1)}>Next</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>Sun</th>
            <th>Mon</th>
            <th>Tue</th>
            <th>Wed</th>
            <th>Thu</th>
            <th>Fri</th>
            <th>Sat</th>
          </tr>
        </thead>
        <tbody>{renderCalendar()}</tbody>
      </table>
      {selectedDate && (
        <div className="event-display-container">
          <h3>Events on {selectedDate}</h3>
          {/* {events[selectedDate] && events[selectedDate].length > 0 ? (
            <ul>
              {events[selectedDate].map((event, index) => (
                <li key={index}>{event}</li>
              ))}
            </ul>
          ) : (
            <>
              <input
                type="text"
                value={eventInput}
                onChange={handleInputChange}
                placeholder="Add event..."
              />
              <button onClick={addEvent} className="add-event-btn">
                Add Event
              </button>
            </>
          )} */}
        </div>
      )}
      <button className="add-event-bottom-btn" onClick={() => goToPage('Eventform')}>
        +
      </button>
    </div>
  );
};

export default Calendar;
