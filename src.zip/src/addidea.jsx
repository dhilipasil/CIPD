import React, { useState } from 'react';
import Select from 'react-select';
import './css/addidea.css';

// Predefined tag options for the dropdown
const tagsOptions = [
  { value: 'web application', label: 'Web Application' },
  { value: 'AI & ML', label: 'AI & ML' },
  { value: 'Deep learning', label: 'Deep Learning' },
  { value: 'Blue Eye', label: 'Blue Eye' },
  { value: 'AR & VR', label: 'AR & VR' },
];

const IdeaForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    problem: '',
    solution: '',
    keyFeatures: '',
    targetAudience: '',
    contactNumber: '',
    linkedinId: '',
    tags: [], // Added tags field for storing selected tag values
  });

  // Handles changes for regular form inputs
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handles changes for tag selection (react-select component)
  const handleTagChange = (selectedOptions) => {
    setFormData({ ...formData, tags: selectedOptions.map(option => option.value) });
  };

  // Submits the form data
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('http://localhost:6600/api/auth/ideaadd', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),  // Send form data including tags
      });

      const data = await response.json();
  
      if (response.ok) {
        alert('Idea Submitted Successfully!');
        console.log('Server Response:', data);
      } else {
        alert('Failed to submit idea');
        console.error('Server Error:', data);
      }
    } catch (error) {
      console.error('Network error:', error);
      alert('Network Error. Please try again later.');
    }
  };

  return (
    <div className="form-container">
      <h2>Submit Your Idea</h2>
      <form onSubmit={handleSubmit} className="idea-form">
        <label>
          Idea Title:
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Description:
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Problem/Need:
          <input
            type="text"
            name="problem"
            value={formData.problem}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Solution:
          <input
            type="text"
            name="solution"
            value={formData.solution}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Key Features:
          <input
            type="text"
            name="keyFeatures"
            value={formData.keyFeatures}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Target Audience:
          <input
            type="text"
            name="targetAudience"
            value={formData.targetAudience}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Contact Number:
          <input
            type="tel"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
            required
            pattern="[0-9]{10}"
          />
        </label>

        <label>
          LinkedIn ID:
          <input
            type="url"
            name="linkedinId"
            value={formData.linkedinId}
            onChange={handleChange}
            required
            placeholder="https://www.linkedin.com/in/your-id"
          />
        </label>

        {/* Tags dropdown using react-select */}
        <label>
          Tags:
          <Select
            isMulti
            options={tagsOptions}
            value={tagsOptions.filter(option => formData.tags.includes(option.value))}
            onChange={handleTagChange} // Ensure this line references the defined function
          />
        </label>

        <button type="submit" className="submit-btn">Submit Idea</button>
      </form>
    </div>
  );
};

export default IdeaForm;
