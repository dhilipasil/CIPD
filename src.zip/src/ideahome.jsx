import React, { useState, useEffect } from "react";
import "./css/Ideahome.css";
import { useNavigate } from 'react-router-dom';

const Ideahome = () => {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [expandedProjects, setExpandedProjects] = useState({});
  const [selectedTags, setSelectedTags] = useState(new Set());
  const [searchTerm, setSearchTerm] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [usedTags, setUsedTags] = useState([]);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await fetch('http://localhost:6600/api/auth/idea');
        if (!response.ok) {
          throw new Error(`Error: ${response.statusText}`);
        }
        const data = await response.json();
        setProjects(data);

        // Get unique tags from the fetched projects
        const tags = [...new Set(data.flatMap(project => project.tags))];
        setUsedTags(tags);
      } catch (error) {
        setErrorMessage("Failed to fetch data. Please check your backend.");
      }
    };

    fetchProjects();
  }, []);

  const filteredProjects = projects.filter(project => {
    const matchesTags = selectedTags.size === 0 || [...selectedTags].some(tag => project.tags.includes(tag));
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesTags && matchesSearch;
  });

  const toggleTag = (tag) => {
    setSelectedTags(prevSelectedTags => {
      const updatedTags = new Set(prevSelectedTags);
      if (updatedTags.has(tag)) {
        updatedTags.delete(tag); // Remove the tag if it's already selected
      } else {
        updatedTags.add(tag); // Add the tag if it's not selected
      }
      return updatedTags;
    });
  };

  return (
    <div className="layout-container">
      {/* Error message */}
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}

      {/* Right Tags Section - display only used tags */}
      <div className="right-tags">
        {usedTags.map((tag) => (
          <button
            key={tag}
            className={`tag-btn ${selectedTags.has(tag) ? "selected" : ""}`}
            onClick={() => toggleTag(tag)}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Center Content */}
      <div className="center-content">
        <input
          type="text"
          className="search-box"
          placeholder="Search projects..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />

        {filteredProjects.map((project, index) => (
          <div key={index} className="details-container">
            <h3>{project.title}</h3>
            <h4>{project.description}</h4>
            
            {/* Display the username of the person who posted the idea */}
            <p><strong>Posted by:</strong> {project.user?.username || "Unknown"}</p>

            {/* Expand/Collapse button */}
            <button
              className="toggle-btn"
              onClick={() => setExpandedProjects(prev => ({ ...prev, [index]: !prev[index] }))}
            >
              {expandedProjects[index] ? "Show Less" : "Show More"}
            </button>

            {/* Expanded project details */}
            {expandedProjects[index] && (
              <div className="expanded-content">
                <p><strong>Problem:</strong> {project.problem}</p>
                <p><strong>Solution:</strong> {project.solution}</p>
                <p><strong>Key Features:</strong> {project.keyFeatures}</p>
                <p><strong>Target Audience:</strong> {project.targetAudience}</p>
                <p><strong>Contact Number:</strong> {project.contactNumber}</p>
                <p><strong>LinkedIn ID:</strong> <a href={project.linkedinId} target="_blank" rel="noopener noreferrer">{project.linkedinId}</a></p>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Floating Add Idea Button */}
      <div className="floating-button" onClick={() => navigate('/ideaadd')}>
        <span>+</span>
      </div>
    </div>
  );
};

export default Ideahome;
