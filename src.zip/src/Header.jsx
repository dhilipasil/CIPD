import React, { useEffect, useState } from 'react';
import './css/Header.css';
import logo from './photo/nandha.jpeg';
import logo2 from './photo/images.png';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';

function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
    }
  }, []);

  const goToPage = (page) => {
    navigate(`/${page}`);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsLoggedIn(false);
    navigate('/Home');
  };

  return (
    <>
      <div className="header-container">
        <img src={logo2} alt="Logo2" className="logo-left" />
        <div className="college-details">
          <h1>NANDHA ENGINEERING COLLEGE</h1>
          <h2>(AUTONOMOUS)</h2>
          <p>Approved by AICTE, New Delhi</p>
          <p>Affiliated to Anna University, Chennai</p>
          <p>Accredited by NAAC (A+) Grade & NBA</p>
        </div>
        <img src={logo} alt="Logo" className="logo-right" />
      </div>

      <div className="menu-container">
        <Button className="menu-button" onClick={() => goToPage('home')}>CiPD</Button>
        <Button className="menu-button" onClick={() => goToPage('idea')}>Idea</Button>
        <Button className="menu-button" onClick={() => goToPage('Calendar')}>Event</Button>
        <Button className="menu-button" onClick={() => goToPage('startup-company')}>Startups</Button>
        <Button className="menu-button" onClick={() => goToPage('About')}>Contact</Button>
        {isLoggedIn ? (
          <Button className="menu-button login-button" onClick={handleLogout}>Logout</Button>
        ) : (
          <Button className="menu-button login-button" onClick={() => goToPage('login')}>Log in</Button>
        )}
      </div>
    </>
  );
}

export default Header;
