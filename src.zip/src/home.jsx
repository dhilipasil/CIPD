import React from 'react';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import './css/home.css';  // Your own custom styles

// Image URLs (You can use your images here)
import image1 from './photo/home3.jpg';  // replace with your images
import image2 from './photo/home1.jpg';  // replace with your images
import image3 from './photo/home2.jpg';  // replace with your images

const Home = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 400, // Faster speed for transitions
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1500, // Faster autoplay speed
    pauseOnHover: true,
  };

  return (
    <div className="app-container">
      <div className="slideshow-container">
        <Slider {...settings}>
          <div>
            <img src={image1} alt="Slide 1" className="slide-image" />
          </div>
          <div>
            <img src={image2} alt="Slide 2" className="slide-image" />
          </div>
          <div>
            <img src={image3} alt="Slide 3" className="slide-image" />
          </div>
        </Slider>
      </div>

      {/* Content */}
      <div className="content">
        <h3>About CiPD</h3>
        <p>
          CiPD was established in Nandha Engineering College in the year 2014 with the aim of
          creating a spark of innovation in students' minds and to expose them to existing problems...
        </p>
      </div>
    </div>
  );
};

export default Home;
