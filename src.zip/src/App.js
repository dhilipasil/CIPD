import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Banner from './Header.jsx';
import LoginPage from './login.jsx';
import SignupPage from './sigup.jsx';
import Ideahome from './ideahome.jsx';
import IdeaForm from './addidea.jsx';
import Calendar from './calendar.jsx';
import EventForm from './addeventcal.jsx';
import Home from './home.jsx';
import About from './about.jsx';

const App = ()=>{
  return(
    <> 
    <BrowserRouter>
      <Routes>
        <Route path="/Home" element={<><Banner /><Home /></>}></Route>
        <Route path="/About" element={<><Banner /><About /></>}></Route>
        <Route path="/idea" element={<><Banner /><Ideahome/></>}></Route>
        <Route path="/eventform" element={<><Banner /><EventForm/></>}></Route>
        <Route path="/Calendar" element={<><Banner /><Calendar /></>}></Route>
        <Route path="/Login" element={<><LoginPage /></>}></Route>
        <Route path="/Signup" element={<><SignupPage /></>}></Route>
        <Route path="/ideaadd" element={<><Banner /><IdeaForm /></>}></Route> 
      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App